<?php
header('Content-type: text/html; charset=utf-8');

echo '<pre>';

// Конфигурация

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Имена таблиц БД (они должны быть созданы заранее)
$database_table_clients = 'clients';
$database_table_merchandise = 'merchandise';
$database_table_orders = 'orders';

$input_file = 'orders_input__.txt'; // Входной файл (должен существовать)
$invalid_file = 'invalid_orders.txt'; // Файл для невалидных строк
$db_host = 'localhost';
$db_name = 'clients_merchandise_orders'; // Должна быть создана
$db_user = 'root';
$db_pass = '';

// Подключение к БД
try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8",
        $db_user,
        $db_pass,
        array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        )
    );
} catch (PDOException $e) {
    die("Ошибка подключения к БД: " . $e->getMessage());
}

// Открываем файлы
$input_handle = fopen($input_file, 'r');
if (!$input_handle) {
    die("Не удалось открыть входной файл: $input_file");
}

$invalid_handle = fopen($invalid_file, 'w');
if (!$invalid_handle) {
    fclose($input_handle);
    die("Не удалось открыть файл для невалидных данных: $invalid_file");
}

$valid_count = 0;
$invalid_count = 0;

echo "Начало обработки файла...\n";

// Читаем файл построчно
while (($line = fgets($input_handle)) !== false) {
    // Убираем BOM, если есть
    if (substr($line, 0, 3) === "\xEF\xBB\xBF") {
        $line = substr($line, 3);
    }

    // Убираем символы новой строки и пробелы по краям
    $line = trim($line);

    // Пропускаем пустые строки
    if (empty($line)) {
        continue;
    }

    // Парсим строку по разделителю ';'
    $parts = explode(';', $line);

    // Проверяем, что в строке ровно 3 части
    $parts = explode(';', $line);
    echo "Парсинг строки '$line': получено " . count($parts) . " полей\n";
    if (count($parts) !== 3) {
        echo "Ошибка: Неверное количество полей\n";
        fwrite($invalid_handle, $line . "\n");
        $invalid_count++;
        continue;
    }

    list($item_id, $customer_id, $comment) = $parts;
    echo "Проверяем ID: товар=$item_id, клиент=$customer_id\n";

    if (!is_numeric($item_id) || !is_numeric($customer_id)) {
        echo "Ошибка: один из ID в данной строке не является числовым:\n";
        print_r($parts);

        echo '    $item_id =' . $item_id . (is_numeric($item_id) ? '-Числовой' : '-Нечисловой') . "\n";
        echo '    $customer_id =' . $customer_id . (is_numeric($customer_id) ? '-Числовой' : '-Нечисловой') . "\n";
        fwrite($invalid_handle, $line . "\n");
        $invalid_count++;
        continue;
    }



    $item_id = (int)$item_id;
    $customer_id = (int)$customer_id;


    $stmt = $pdo->prepare("SELECT id FROM merchandise WHERE id = ?");
    $stmt->execute(array($item_id));
    $product_exists = $stmt->fetch();
    echo "Товар с ID $item_id " . ($product_exists ? "найден" : "не найден") . "\n";
    if (!$product_exists) {
        echo "Ошибка: Товар не существует\n";
        fwrite($invalid_handle, $line . "\n");
        $invalid_count++;
        continue;
    }


    // Проверка существования клиента
   /* $stmt = $pdo->prepare("SELECT id FROM clients WHERE id = ?");
    $stmt->execute(array($customer_id));
    if (!$stmt->fetch()) {
        fwrite($invalid_handle, $line . "\n");
        $invalid_count++;
        continue;
    }*/

    $stmt = $pdo->prepare("SELECT id FROM clients WHERE id = ?");
    $stmt->execute(array($customer_id));
    $client_exists = $stmt->fetch();
    echo "Клиент с ID $customer_id " . ($client_exists ? "найден" : "не найден") . "\n";
    if (!$client_exists) {
        echo "Ошибка: Клиент не существует\n";
        fwrite($invalid_handle, $line . "\n");
        $invalid_count++;
        continue;
    }

    // Все проверки пройдены — добавляем заказ в БД
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO orders (item_id, customer_id, comment, status, order_date)
             VALUES (?, ?, ?, 'new', NOW())"
        );
        $stmt->execute(array($item_id, $customer_id, $comment));
        $valid_count++;
    } catch (PDOException $e) {
        // Если ошибка при вставке, записываем в невалидные
       /* fwrite($invalid_handle, $line . " (ошибка БД: " . $e->getMessage() . ")\n");
        $invalid_count++;*/

        $error_msg = "Ошибка вставки для строки '$line': " . $e->getMessage();
        echo $error_msg . "\n";
        fwrite($invalid_handle, $line . " (ошибка БД: " . $e->getMessage() . ")\n");
        $invalid_count++;

    }
}

// Закрываем файлы
fclose($input_handle);
fclose($invalid_handle);

echo "Обработка завершена.\n";
echo "Обработано строк: " . ($valid_count + $invalid_count) . "\n";
echo "Успешно добавлено заказов: $valid_count\n";
echo "Невалидных строк: $invalid_count\n";
